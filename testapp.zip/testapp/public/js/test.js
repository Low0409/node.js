document.write("jsの文章");
alert("helo");