//publicフォルダを作り、その中にcss、jsフォルダ,htmlなどを入れた
//expressに書き換えた
const express = require('express')
const app = express()
const port = 3000
const path = require('path')

app.use(express.static(path.join(__dirname, 'public')))

app.use(function(req, res){
    res.status(404);
    res.sendFile(__dirname + "/"+ 'public/404.html')
});

app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))


