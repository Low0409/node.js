const express = require("express");
const app = express();
const http = require("http");
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);

const userHash = {}; // 参加中のユーザの名前を保持
const connectedUsers = {}; // private messageに使用

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});
io.on("connection", (socket) => {
  socket.on("disconnect", () => {
    socket.broadcast.emit("chat message", `${socket.userName}が退室しました`); // 送ってきた本人以外に送信
    delete userHash[socket.id];
    io.emit("users count", userHash);
  });

  socket.on("chat message", (msg) => {
    //io.emit("chat message", `${socket.userName}: ${message}`);
    io.emit('chat message', msg + "【＠" + socket.userName + "】");           //自分と相手

  });

  socket.on("private message", (data) => {
    const from = data.from,
      to = data.to,
      message = data.message;
    if (connectedUsers.hasOwnProperty(to)) {
      connectedUsers[from].emit(
        "chat message",
        `DM (${from} -> ${to}): ${message}`
      );
      connectedUsers[to].emit(
        "chat message",
        `DM (${from} -> ${to}): ${message}`
      );
    }
  });

  socket.on("enter room", (userName) => {
    connectedUsers[userName] = socket;
    socket.userName = userName;
    userHash[socket.id] = socket.userName;
    io.emit("chat message", `${socket.userName}が入室しました`);
    io.emit("users count", userHash);
  });


  socket.on('image', (imageData) => {
    //socket.broadcast.emit('image', imageData);
    io.emit('image', imageData);

    //socket.broadcast.emit('chat message',imageData);//コードのまま

  });
});
server.listen(3000, () => {
  console.log("listening on *:3000");
});